Installation:


1.	Move the files in the zip to any location you wish (EG: Documents, Program Files, Etc.)
2.	On 1st run, app will create a "Tasks" folder under your user documents folder.
3.	Press your start menu and search for "task scheduler"
4.	Add a new task for the time of day you wish dopamine bar to appear on your desktop.
5.	See picture for task scheduler option I recommend.

Known bugs:

Software does not like windows screen scaling above 100%. I haven't figured out how to make it work.

Software is written in VB6, if you'd like to improve it please share it with me:
spacehey.com/guitarninja